import time
import random
import string
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt



# BST CLASSES


class BSTContact:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return BSTContact(name, phone)

        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone

        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root

        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left

            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        return root



# AVL CLASSES


class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        if not node:
            return 0
        return node.height

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        t3 = y.right

        y.right = z
        z.left = t3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y

    def left_rotate(self, z):
        y = z.right
        t2 = y.left

        y.left = z
        z.right = t2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)

        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        # Left Left
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)

        # Right Right
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)

        # Left Right
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)

        # Right Left
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left

            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        if root is None:
            return root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        # Left Left
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)

        # Left Right
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        # Right Right
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)

        # Right Left
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root

        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)



# BENCHMARK FUNCTIONS


def generate_contacts(n):
    names = [''.join(random.choices(string.ascii_lowercase, k=7)) + str(i) for i in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
    return names, phones


def benchmark(n=1000, verbose=True):
    bst = BST()
    avl = AVLTree()

    names, phones = generate_contacts(n)

    # INSERT
    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert_time = time.time() - start

    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert_time = time.time() - start

    # SEARCH
    search_names = random.sample(names, n // 2) + ['notfoundname'] * (n // 2)

    start = time.time()
    found_bst = 0
    for name in search_names:
        if bst.search(bst.root, name):
            found_bst += 1
    bst_search_time = time.time() - start

    start = time.time()
    found_avl = 0
    for name in search_names:
        if avl.search(avl.root, name):
            found_avl += 1
    avl_search_time = time.time() - start

    # DELETE
    delete_names = random.sample(names, min(100, n))

    start = time.time()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete_time = time.time() - start

    start = time.time()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete_time = time.time() - start

    results = {
        "Insertions": (bst_insert_time, avl_insert_time),
        "Searches": (bst_search_time, avl_search_time),
        "Deletions": (bst_delete_time, avl_delete_time),
        "Found In Search": (found_bst, found_avl)
    }

    if verbose:
        print(f"\nBenchmarking with {n} entries:\n")
        print("Operation      BST Time (sec)    AVL Time (sec)")
        print("------------------------------------------------")
        print(f"Insertions     {bst_insert_time:.6f}         {avl_insert_time:.6f}")
        print(f"Searches       {bst_search_time:.6f}         {avl_search_time:.6f}")
        print(f"Deletions      {bst_delete_time:.6f}         {avl_delete_time:.6f}")
        print("------------------------------------------------")
        print(f"Found in Search: BST = {found_bst}, AVL = {found_avl}")

    return results


def run_benchmark_for_sizes(sizes):
    bst_insert = []
    avl_insert = []

    bst_search = []
    avl_search = []

    bst_delete = []
    avl_delete = []

    for n in sizes:
        results = benchmark(n, verbose=False)

        bst_insert.append(results["Insertions"][0])
        avl_insert.append(results["Insertions"][1])

        bst_search.append(results["Searches"][0])
        avl_search.append(results["Searches"][1])

        bst_delete.append(results["Deletions"][0])
        avl_delete.append(results["Deletions"][1])

    # Graph 1: Insert
    plt.figure(figsize=(8, 5))
    plt.plot(sizes, bst_insert, marker='o', label='BST Insert')
    plt.plot(sizes, avl_insert, marker='o', label='AVL Insert')
    plt.xlabel("Number of Nodes")
    plt.ylabel("Time (seconds)")
    plt.title("Insertion Time vs Input Size")
    plt.legend()
    plt.grid(True)
    plt.show()

    # Graph 2: Search
    plt.figure(figsize=(8, 5))
    plt.plot(sizes, bst_search, marker='o', label='BST Search')
    plt.plot(sizes, avl_search, marker='o', label='AVL Search')
    plt.xlabel("Number of Nodes")
    plt.ylabel("Time (seconds)")
    plt.title("Search Time vs Input Size")
    plt.legend()
    plt.grid(True)
    plt.show()

    # Graph 3: Delete
    plt.figure(figsize=(8, 5))
    plt.plot(sizes, bst_delete, marker='o', label='BST Delete')
    plt.plot(sizes, avl_delete, marker='o', label='AVL Delete')
    plt.xlabel("Number of Nodes")
    plt.ylabel("Time (seconds)")
    plt.title("Deletion Time vs Input Size")
    plt.legend()
    plt.grid(True)
    plt.show()



# GUI APP


class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL Benchmark")

        self.label = tk.Label(master, text="Run benchmark with 1000 entries")
        self.label.pack(pady=5)

        self.run_btn = tk.Button(master, text="Run Benchmark", command=self.run_benchmark)
        self.run_btn.pack(pady=5)

        self.result_text = tk.Text(master, height=12, width=60)
        self.result_text.pack(pady=10)

        self.tree = ttk.Treeview(master, columns=("Operation", "BST", "AVL"), show="headings")
        self.tree.heading("Operation", text="Operation")
        self.tree.heading("BST", text="BST Time (s)")
        self.tree.heading("AVL", text="AVL Time (s)")
        self.tree.pack(pady=10)

    def run_benchmark(self):
        self.result_text.delete(1.0, tk.END)

        results = benchmark(1000, verbose=False)

        summary = (
            f"Insertion Time: BST = {results['Insertions'][0]:.6f}s, AVL = {results['Insertions'][1]:.6f}s\n"
            f"Search Time:    BST = {results['Searches'][0]:.6f}s, AVL = {results['Searches'][1]:.6f}s\n"
            f"Deletion Time:  BST = {results['Deletions'][0]:.6f}s, AVL = {results['Deletions'][1]:.6f}s\n"
            f"Found in Search: BST = {results['Found In Search'][0]}, AVL = {results['Found In Search'][1]}\n"
        )

        self.result_text.insert(tk.END, summary)

        for row in self.tree.get_children():
            self.tree.delete(row)

        for op in ["Insertions", "Searches", "Deletions"]:
            bst_time, avl_time = results[op]
            self.tree.insert("", tk.END, values=(op, f"{bst_time:.6f}", f"{avl_time:.6f}"))



# MAIN


if __name__ == "__main__":
    #root = tk.Tk()
    #app = BenchmarkApp(root)
    #root.mainloop()

     sizes_to_test = [100, 500, 1000, 2000, 5000, 10000]
     run_benchmark_for_sizes(sizes_to_test)

# Use hashtag on lines 404,405,406 to see graph and unhash 408 and 409.
# Use hashtag on lines 408,409 to see Benchmark GUI and unhash 404, 405 and 406.