import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 20
CANVAS_WIDTH = 700
CANVAS_HEIGHT = 220


class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = []

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg="white")
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Push Value:").grid(row=0, column=0)
        self.enqueue_entry = tk.Entry(control_frame, width=10)
        self.enqueue_entry.grid(row=0, column=1)

        enqueue_btn = tk.Button(control_frame, text="Push", command=self.enqueue_value)
        enqueue_btn.grid(row=0, column=2, padx=5)

        dequeue_btn = tk.Button(control_frame, text="Pop", command=self.dequeue_value)
        dequeue_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(
            x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
            fill="lightgreen", outline="black", width=2
        )
        self.canvas.create_text(
            x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2,
            text=str(data), font=("Arial", 16)
        )

    def draw_arrow(self, x1, y1, x2, y2):
        self.canvas.create_line(x1, y1, x2, y2, arrow=tk.LAST, width=2)

    def draw_queue(self):
        self.canvas.delete("all")

        x = 30
        y = 80
        centers = []

        for val in self.queue:
            self.draw_node(x, y, val)
            centers.append((x + NODE_WIDTH / 2, y + NODE_HEIGHT / 2))
            x += NODE_WIDTH + HORIZONTAL_GAP

        for i in range(len(centers) - 1):
            x1, y1 = centers[i]
            x2, y2 = centers[i + 1]
            self.draw_arrow(x1 + NODE_WIDTH / 2 - 40, y1, x2 - NODE_WIDTH / 2 + 40, y2)

        if self.queue:
            first_x = 30
            last_x = 30 + (len(self.queue) - 1) * (NODE_WIDTH + HORIZONTAL_GAP)

            self.canvas.create_text(
                first_x + NODE_WIDTH / 2, y - 25,
                text="Front", font=("Arial", 12), fill="red"
            )
            self.canvas.create_text(
                last_x + NODE_WIDTH / 2, y + NODE_HEIGHT + 20,
                text="Rear", font=("Arial", 12), fill="blue"
            )

    def enqueue_value(self):
        try:
            val = int(self.enqueue_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to enqueue.")
            return

        self.queue.append(val)
        self.enqueue_entry.delete(0, tk.END)
        self.status_label.config(text=f"Enqueued {val} into queue")
        self.draw_queue()

    def dequeue_value(self):
        if len(self.queue) == 0:
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot dequeue.")
            return

        val = self.queue.pop(0)
        self.status_label.config(text=f"Popped {val} from queue")
        self.draw_queue()


if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)


    root.mainloop()