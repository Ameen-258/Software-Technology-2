from graph import Graph

print("========== TASK 1: GRAPH BASICS ==========")

print("\nUndirected graph test:")
g1 = Graph()
for v in ['A', 'B', 'C', 'D']:
    g1.add_vertex(v)

g1.print_graph()
print()

g1.add_edge('A', 'B')
print("After adding edge A-B:")
g1.print_graph()
print()

g1.add_edge('B', 'C')
print("After adding edge B-C:")
g1.print_graph()
print()

g1.add_edge('C', 'D')
print("After adding edge C-D:")
g1.print_graph()
print()

g1.remove_edge('A', 'B')
print("After removing edge A-B:")
g1.print_graph()
print()

g1.remove_vertex('D')
print("After removing vertex D:")
g1.print_graph()
print()

print("Directed graph test:")
g2 = Graph(directed=True)
for v in ['A', 'B', 'C', 'D']:
    g2.add_vertex(v)

g2.add_edge('A', 'B')
g2.add_edge('B', 'C')
g2.add_edge('C', 'D')

g2.print_graph()
print()

print("Weighted directed graph test:")
g3 = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    g3.add_vertex(v)

g3.add_edge('A', 'B', 15)
g3.add_edge('B', 'C', 34)

g3.print_graph()
print()

print("========== TASK 2: BFS ==========")
bfs_graph = Graph(directed=True)
for v in ['A', 'B', 'C', 'D', 'E']:
    bfs_graph.add_vertex(v)

bfs_graph.add_edge('A', 'B')
bfs_graph.add_edge('A', 'C')
bfs_graph.add_edge('B', 'D')
bfs_graph.add_edge('C', 'E')

bfs_graph.print_graph()
print("BFS starting from vertex 'A':")
visited_bfs = bfs_graph.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)
print()

print("========== TASK 3: DFS ==========")
print("DFS starting from vertex 'A':")
visited_dfs = bfs_graph.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)
print()

print("========== TASK 4: CYCLE DETECTION IN UNDIRECTED GRAPHS ==========")

cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')

print("cycle_graph:")
cycle_graph.print_graph()
print("Does cycle_graph have a cycle?", cycle_graph.has_undirected_cycle())
print()

acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

print("acyclic_graph:")
acyclic_graph.print_graph()
print("Does acyclic_graph have a cycle?", acyclic_graph.has_undirected_cycle())
print()

print("========== TASK 5: WEIGHTED AND DIRECTED GRAPHS ==========")

wg = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)

wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)

print("Weighted Directed Graph:")
wg.print_graph()
print()

print("Directed cycle check example:")
dg_cycle = Graph(directed=True)
for v in ['A', 'B', 'C', 'D']:
    dg_cycle.add_vertex(v)

dg_cycle.add_edge('A', 'B')
dg_cycle.add_edge('B', 'C')
dg_cycle.add_edge('C', 'A')
dg_cycle.add_edge('C', 'D')

dg_cycle.print_graph()
print("Does dg_cycle have a directed cycle?", dg_cycle.has_directed_cycle())