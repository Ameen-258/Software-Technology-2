from collections import deque


class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 not in self.graph or vertex2 not in self.graph:
            print("One or both vertices not found in graph.")
            return

        if vertex2 not in self.graph[vertex1]:
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight

        if not self.directed:
            if vertex1 not in self.graph[vertex2]:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if (vertex1, vertex2) in self.weights:
                del self.weights[(vertex1, vertex2)]

        if not self.directed and vertex2 in self.graph and vertex1 in self.graph[vertex2]:
            self.graph[vertex2].remove(vertex1)
            if (vertex2, vertex1) in self.weights:
                del self.weights[(vertex2, vertex1)]

    def remove_vertex(self, vertex):
        if vertex not in self.graph:
            return

        for v in self.graph:
            if vertex in self.graph[v]:
                self.graph[v].remove(vertex)
            if (v, vertex) in self.weights:
                del self.weights[(v, vertex)]

        for edge in list(self.weights.keys()):
            if vertex in edge:
                del self.weights[edge]

        del self.graph[vertex]

    def print_graph(self):
        print("Graph:")
        for vertex in self.graph:
            if self.weighted:
                edges = []
                for nbr in self.graph[vertex]:
                    w = self.weights.get((vertex, nbr), 0)
                    edges.append(f"{nbr}({w})")
                print(f"{vertex} -> {edges}")
            else:
                print(f"{vertex} -> {self.graph[vertex]}")

    def bfs(self, start_vertex):
        if start_vertex not in self.graph:
            return []

        visited = []
        seen = set([start_vertex])
        queue = deque([start_vertex])

        while queue:
            current = queue.popleft()
            visited.append(current)

            for nbr in self.graph[current]:
                if nbr not in seen:
                    seen.add(nbr)
                    queue.append(nbr)

        return visited

    def dfs(self, start_vertex):
        if start_vertex not in self.graph:
            return []

        visited = []
        seen = set()
        stack = [start_vertex]

        while stack:
            current = stack.pop()
            if current not in seen:
                seen.add(current)
                visited.append(current)

                for nbr in reversed(self.graph[current]):
                    if nbr not in seen:
                        stack.append(nbr)

        return visited

    def has_undirected_cycle(self):
        if self.directed:
            return False

        visited = set()

        def dfs(vertex, parent):
            visited.add(vertex)
            for nbr in self.graph[vertex]:
                if nbr not in visited:
                    if dfs(nbr, vertex):
                        return True
                elif nbr != parent:
                    return True
            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs(vertex, None):
                    return True
        return False

    def has_directed_cycle(self):
        if not self.directed:
            return False

        visited = set()
        rec_stack = set()

        def dfs(vertex):
            visited.add(vertex)
            rec_stack.add(vertex)

            for nbr in self.graph[vertex]:
                if nbr not in visited:
                    if dfs(nbr):
                        return True
                elif nbr in rec_stack:
                    return True

            rec_stack.remove(vertex)
            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs(vertex):
                    return True
        return False